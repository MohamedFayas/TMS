package com.trainingmanagement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class ViewHistory {
	private int username;
	private String coursename;
	private Date startdate;
	private Date enddate;
	static Logger logger=Logger.getLogger(ViewHistory.class);
	
	public int getUsername() {
		return username;
	}
	public void setUsername(int username) {
		this.username = username;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	PreparedStatement pst;
	Connection con;
	public List<ViewHistory> viewHistory(int eno){
	List<ViewHistory> list=new ArrayList();
	ViewHistory obj;
	String sql="select r.username as username,t.coursename as coursename,s.startdate as startdate ,s.enddate as enddate "
			+ "from registercourse r inner join scheduletraining s  on r.trainingid=s.trainingid inner join trainingcourses t on "
			+ "t.courseid=s.courseid where username=?";
	con=DaoConnection.getConnection();
	try {
		obj=new ViewHistory();
		pst=con.prepareStatement(sql);
		pst.setInt(1, eno);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
			list=new ArrayList();
			obj.setUsername(rs.getInt("username"));
			obj.setCoursename(rs.getString("coursename"));
			obj.setStartdate(rs.getDate("startdate"));
			obj.setEnddate(rs.getDate("enddate"));
			list.add(obj);
		}
		return list;
	} catch (SQLException e) {
		logger.error(e.getMessage());
	}
	return list;
	}
}

