package com.trainingmanagement;
import java.sql.Connection;
import java.sql.DriverManager;

import org.apache.log4j.Logger;

public class DaoConnection {
	public static Connection getConnection(){
		GetUserPass obj=new GetUserPass().userPass();
		Logger logger=Logger.getLogger(DaoConnection.class);
		try {
			final String str="oracle.jdbc.driver.OracleDriver";
			Class.forName(str);
			return (DriverManager.getConnection(
					"jdbc:oracle:thin:localhost:1521:ORCL",obj.getUsername(),obj.getPassword()));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;	
	}
}