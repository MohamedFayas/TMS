package com.trainingmanagement;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
public class Users {
	static Logger logger=Logger.getLogger(Users.class);
	int empno;
	String name;
	String job;
	int mgrno;
	String contactNumber;
	String mail;
	String password;
	String typeUser;
	int cntPeople;
	double rating;
	public int getCntPeople() {
		return cntPeople;
	}
	public void setCntPeople(int cntPeople) {
		this.cntPeople = cntPeople;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getTypeUser() {
		return typeUser;
	}
	public void setTypeUser(String typeUser) {
		this.typeUser = typeUser;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public int getMgrno() {
		return mgrno;
	}
	public void setMgrno(int mgrno) {
		this.mgrno = mgrno;
	}
	int salary;
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	Connection con;
	PreparedStatement pst;
	CallableStatement stmt;
	public int generateUserId()  {
		String sql="select case when max(username) is null then 1 else max(username)+1 end eno from Login";
		try {
			con=DaoConnection.getConnection();
			pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				return rs.getInt("eno");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return 0;
	}
	public String createUsers(Users obj,String pwd,String typ) {
		con=DaoConnection.getConnection();
		typ=typ.toUpperCase();
		try {
			stmt = con.prepareCall("{call prcAddUser(?,?,?,?,?,?,?,?,?)}");
			stmt.setInt(1,obj.getEmpno());
			stmt.setString(2, pwd);
			stmt.setString(3,typ );
			stmt.setString(4,obj.getName());
			stmt.setString(5,obj.getJob());
			stmt.setInt(6,obj.getSalary());
			stmt.setInt(7, obj.getMgrno());
			stmt.setString(8,obj.getContactNumber());
			stmt.setString(9,obj.getMail());
			stmt.executeUpdate();
			return "New User Added Successfully";
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}
	public Users viewDetails(int eno) {
		Users objUsers=new Users();
		try {
				con=DaoConnection.getConnection();
				stmt = con.prepareCall("{call prcAboutUsers(?,?,?,?,?,?,?)}");
				stmt.setInt(1,eno);
				stmt.registerOutParameter(2, Types.VARCHAR);
				stmt.registerOutParameter(3,Types.VARCHAR);
				stmt.registerOutParameter(4,Types.INTEGER);
				stmt.registerOutParameter(5,Types.INTEGER);
				stmt.registerOutParameter(6,Types.VARCHAR);
				stmt.registerOutParameter(7,Types.VARCHAR);
				stmt.execute();
				objUsers.setEmpno(eno);
				objUsers.setName(stmt.getString(2));
				objUsers.setJob(stmt.getString(3));
				objUsers.setSalary(stmt.getInt(4));
				objUsers.setMgrno(stmt.getInt(5));
				objUsers.setContactNumber(stmt.getString(6));
				objUsers.setMail(stmt.getString(7));
				return objUsers;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return objUsers;
	}

	public String generateCourseId(){
		 con=DaoConnection.getConnection();
		String cmd="select case when max(CourseId) is null then 'C000' else max(CourseId) end Cid from  TrainingCourses";
		
		try {
			PreparedStatement ps;
			ps=con.prepareStatement(cmd);
			ResultSet rs=ps.executeQuery(); 
			rs.next();
			String courseId=rs.getString("Cid");
			int sp=Integer.parseInt(courseId.substring(1));
			sp++;
			String newCourseId="";
			if(sp >=1 && sp <= 9) {
				newCourseId="C00"+sp;
			}
			if(sp >=10 && sp <= 99) {
				newCourseId="C0"+sp;
			}
			if(sp >=100 && sp <= 999) {
				newCourseId="C"+sp;
			}
			return newCourseId;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}
	public String generateTrainingId(){
		con=DaoConnection.getConnection();
		String cmd="select case when max(TrainingId) is null then 'T000' else max(TrainingId) end Tid from  ScheduleTraining";
		
		try {
			PreparedStatement ps;
			ps=con.prepareStatement(cmd);
			ResultSet rs=ps.executeQuery(); 
			rs.next();
			String trainingId=rs.getString("Tid");
			int sp=Integer.parseInt(trainingId.substring(1));
			sp++;
			String newTrainingId="";
			if(sp >=1 && sp <= 9) {
				newTrainingId="T00"+sp;
			}
			if(sp >=10 && sp <= 99) {
				newTrainingId="T0"+sp;
			}
			if(sp >=100 && sp <= 999) {
				newTrainingId="T"+sp;
			}
			return newTrainingId;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}
	
	
	public String postTraining(String courseId,String empNo,String courseName)
	{
		String msg=null;
		int eno=Integer.parseInt(empNo);
		con=DaoConnection.getConnection();
		try {
			pst=con.prepareStatement("Insert into TrainingCourses(courseId,empno,courseName) Values(?,?,?)");
			pst.setString(1, courseId);
			pst.setInt(2, eno);
			pst.setString(3, courseName);
			pst.executeQuery();
			return "Training Posted successfully";
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return msg;
	}
	public String updateStatus(String aprv,String regId) {
		con=DaoConnection.getConnection();
		String cmd="Update  RegisterCourse set ApprovalStatus=? where registerId=?";
		try {
			pst=con.prepareStatement(cmd);
			pst.setString(1, aprv);
			pst.setString(2, regId);
			pst.executeUpdate();
			return aprv+" succesfully........";	
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "Not updated";
	}
	public String validateUsers(int user,String pwd) {
		
		con=DaoConnection.getConnection();
		try {
				stmt=con.prepareCall("{call prcLoginCheck(?,?,?,?)}");
				stmt.setInt(1, user);
				stmt.setString(2, pwd);
				stmt.registerOutParameter(3,Types.VARCHAR);
				stmt.registerOutParameter(4,Types.INTEGER);
				stmt.executeQuery();
				int flag=stmt.getInt(4);
				if(flag!=0) {
					return stmt.getString(3);
				}
				else {
					return null;
				}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return null;
	}
	String dat="yyyy-MM-dd";
	public String dateFormat(String str) {
		 SimpleDateFormat formatter1=new SimpleDateFormat(dat);
		 SimpleDateFormat formatter2=new SimpleDateFormat("dd-MMM-yyyy");
		 try {
				Date date2=formatter1.parse(str);
				return formatter2.format(date2);
			} catch (ParseException e) {
				logger.error(e.getMessage());
			}
		return "Date Format must be(MM/dd/yyyy)";
	}
	public int verifyDate(String sDate,String eDate) {
		try {
			Date dt1=new SimpleDateFormat(dat).parse(sDate); 
			Date dt2=new SimpleDateFormat(dat).parse(eDate);
			Date dt3=new Date();
			if(dt1.compareTo(dt2)>=0||dt1.compareTo(dt3)<=0||dt2.compareTo(dt3)<=0) {
				return 0;
			}
			else {
				return 1;
			}
		} catch (ParseException e) {
			logger.error(e.getMessage());
		}
		return 0;
	}
	public void updateFeedback(String tid)
	{
		con=DaoConnection.getConnection();
		 String sql="insert into feedback values(?,?,?)";
		 try {
			pst=con.prepareStatement(sql);
			pst.setString(1, tid);
			pst.setDouble(2, 0);
			pst.setInt(3, 0);
			pst.executeQuery();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		
	}
	public String scheduleTraining(String courseId,String trainingId,String sDate,String eDate,String venue) {
		con=DaoConnection.getConnection();
		Users objUsers=new Users();
		if(objUsers.verifyDate(sDate, eDate)==1) {
			eDate=objUsers.dateFormat(eDate);
			sDate=objUsers.dateFormat(sDate);
			String cmd="Insert into ScheduleTraining(Trainingid,courseid,startDate,endDate,venue) values(?,?,?,?,?)";
			try {
				pst=con.prepareStatement(cmd);
				pst.setString(1,trainingId);
				pst.setString(2, courseId);
				pst.setString(3, sDate);
				pst.setString(4, eDate);
				pst.setString(5, venue);
				pst.executeQuery();
				objUsers.updateFeedback(trainingId);
				return "Scheduled Successfully.......";
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
			return "Error";
		}
	else {
			return "Date must be Greater than current date and end date must be greater than start date ";
		}
	}
	public List<Users> viewUsers(){
		String sql="select l.userName as empNo ,password,EmployeeName,typeUser,job"
				+ " from login l inner join users on l.username=users.empno order by users.empno ";
		con=DaoConnection.getConnection();
		Users objUsers=new Users();
		List<Users> listUsers=new ArrayList();
		try {
			pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				objUsers=new Users();
				objUsers.setEmpno(rs.getInt("empNo"));
				objUsers.setName(rs.getString("EmployeeName"));
				objUsers.setPassword(rs.getString("password"));
				objUsers.setTypeUser(rs.getString("typeUser"));
				objUsers.setJob(rs.getString("job"));
				listUsers.add(objUsers);
			}
			return listUsers;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return listUsers;
	}
	public String updateUsers(Users obj) {
		con=DaoConnection.getConnection();
		String sql="Update users set Job=?,Salary=?,MgrNo=?,ContactNumber=? where Empno=?";
		try {
			pst=con.prepareStatement(sql);
			pst.setString(1, obj.getJob());
			pst.setInt(2, obj.getSalary());
			pst.setInt(3,obj.getMgrno());
			pst.setString(4, obj.getContactNumber());
			pst.setInt(5, obj.getEmpno());
			pst.executeQuery();
			return "Updated Successfully..........";
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	return "Contact to Developer.......";
	}
	public String getUserName(int empNo) {
		con=DaoConnection.getConnection();
		String cmd="select employeeName from users where empNo=?";
		try {
			pst=con.prepareStatement(cmd);
			pst.setInt(1, empNo);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				return rs.getString("employeeName");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "Contact to Developer.......";
	}
	public int searchRegisteredUsers(String tid,int eno) {
		con=DaoConnection.getConnection();
		try {
			pst=con.prepareStatement("Select count(*) as res from registercourse where trainingid=? and username=?");
			pst.setString(1, tid);
			pst.setInt(2, eno);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				return rs.getInt("res");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}	
		return 0;
		
	}
	public String registerCourse(String tid,int empno) {
		Users objUsers=new Users();
		int res=objUsers.searchRegisteredUsers(tid, empno);
		if(res>=1) {
			return "Already registered...........";
		}
		con=DaoConnection.getConnection();
		String sql="Insert into RegisterCourse(RegisterId,TrainingId,Username)values(?,?,?)";
		Employee obj=new Employee();
		String rid=obj.generateRegisterId();
		try {
			pst=con.prepareStatement(sql);
			pst.setString(1,rid);
			pst.setString(2, tid);
			pst.setInt(3, empno);
			pst.executeQuery();
			return "Registered Successfully";
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return "Contact to developer";
	}
	
	public String giveFeedback(String trainingId,int rating){
		con=DaoConnection.getConnection();
		try {
				stmt=con.prepareCall("{call prcGiveFeedback(?,?)}");
				stmt.setString(1,trainingId);
				stmt.setInt(2,rating);
				stmt.executeQuery();
				return "Successfully rated...";
			} catch (SQLException e) {
				logger.error(e.getMessage());
		}	
		return "Contact to developer...";
	}
	public Users viewFeedback(String trainingId){
		con=DaoConnection.getConnection();
		Users objUsers=new Users();
		try {
				stmt=con.prepareCall("{call prcViewFeedback(?,?,?)}");
				stmt.setString(1,trainingId);
				stmt.registerOutParameter(2,Types.DOUBLE);
				stmt.registerOutParameter(3,Types.INTEGER);
				stmt.executeQuery();
				objUsers.setCntPeople(stmt.getInt(3));
				objUsers.setRating(stmt.getDouble(2));
				
				return objUsers;
			} catch (SQLException e) {
				logger.error(e.getMessage());
		}	
		return null;
	}
	
}
