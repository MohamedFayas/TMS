package com.trainingmanagement;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;
public class Employee {
	static Logger logger=Logger.getLogger(Employee.class);
	private int username;
	private String password;
	private int empno;
	private String employeename;
	private String job;
	private int salary;
	private int mgrno;
	private String contactnumber;
	private String email;
	private String trainingid;
	private String courseid;
	private String venue;
	private Date startdate;
	private Date enddate;
	private String registerid;
	private String approvalstatus;
	private Double rating;
	private int cntpeople;		
	public int getUsername() {
		return username;
	}

	public void setUsername(int username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEmployeename() {
		return employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getMgrno() {
		return mgrno;
	}

	public void setMgrno(int mgrno) {
		this.mgrno = mgrno;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTrainingid() {
		return trainingid;
	}

	public void setTrainingid(String trainingid) {
		this.trainingid = trainingid;
	}

	public String getCourseid() {
		return courseid;
	}

	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	

	public String getRegisterid() {
		return registerid;
	}

	public void setRegisterid(String registerid) {
		this.registerid = registerid;
	}

	public String getApprovalstatus() {
		return approvalstatus;
	}

	public void setApprovalstatus(String approvalstatus) {
		this.approvalstatus = approvalstatus;
	}
	
	

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public int getCntpeople() {
		return cntpeople;
	}

	public void setCntpeople(int cntpeople) {
		this.cntpeople = cntpeople;
	}



	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	CallableStatement stmt;
		
	public Double viewFeedback(String trainingId,int empNo){
		con=DaoConnection.getConnection();
		double rat;
		try {
			stmt=con.prepareCall("{call prcViewFeedback(?,?,?,?}");
			stmt.setInt(1, empNo);
			stmt.setString(2, trainingId);
			stmt.registerOutParameter(3,Types.DOUBLE);
			stmt.registerOutParameter(4,Types.INTEGER);
			stmt.executeQuery();
			rat=stmt.getDouble(3);
			return rat;
			
		} catch (SQLException err) {
			logger.error(err.getMessage());
		}
		return null;
	}
	
	public Employee[] register(String trainingid){
		Employee[] e=null;
		con=DaoConnection.getConnection();
		try {
			ps=con.prepareStatement("SELECT count(*) cnt FROM Registercourse where trainingid=?");
			ps.setString(1, trainingid);
			rs=ps.executeQuery();
			rs.next();
			int cnt=rs.getInt("cnt");
			e=new Employee[cnt];
			String cmd="SELECT * FROM Registercourse where trainingid=?";
			ps=con.prepareStatement(cmd);
			ps.setString(1, trainingid);
			rs=ps.executeQuery();
			Employee e1=null;
			int i=0;
			while(rs.next()) {
				e1=new Employee();
				e1.setRegisterid(rs.getString("RegisterID")); 
				e1.setCourseid(rs.getString("TrainingID"));
				e1.setUsername(rs.getInt("username"));
				e1.setApprovalstatus(rs.getString("ApprovalStatus"));  
				e[i]=e1;
				i++;
			}
		}catch (SQLException err) {
			logger.error(err.getMessage());
		} 
		return e;
	}
	public Employee[] viewSchedule(String courseid){
		Employee[] e=null;
		con=DaoConnection.getConnection();
		try {
			ps=con.prepareStatement("SELECT count(*) cnt FROM ScheduleTraining where courseid=?");
			ps.setString(1, courseid);
			rs=ps.executeQuery();
			rs.next();
			int cnt=rs.getInt("cnt");
			e=new Employee[cnt];
			ps=con.prepareStatement("select * from scheduleTraining where courseid=?");
			ps.setString(1, courseid);
			rs=ps.executeQuery();
			Employee e1=null;
			int i=0;
			while(rs.next()) {
				e1=new Employee();
				e1.setTrainingid(rs.getString("TrainingID")); 
				e1.setCourseid(rs.getString("CourseID"));
				e1.setVenue(rs.getString("Venue"));
				e1.setStartdate(rs.getDate("StartDate")); 
				e1.setEnddate(rs.getDate("EndDate"));
				e[i]=e1;
				i++;
			}
			return e;				
		} catch (SQLException err) {
			logger.error(err.getMessage());
		} 
		return e;
	}
	
	@Override
	public String toString() {
		return "Employee [trainingid=" + trainingid + ", courseid=" + courseid + ", venue=" + venue + ", startdate="
				+ startdate + ", enddate=" + enddate + "]";
	}

	public String generateCourseId(){
		 con=DaoConnection.getConnection();
		String cmd="select case when max(CourseId) is null then 'C000' else max(CourseId) end Cid from  TrainingCourses";
		try {
			ps=con.prepareStatement(cmd);
			 rs=ps.executeQuery(); 
			rs.next();
			String courseId=rs.getString("Cid");
			int sp=Integer.parseInt(courseId.substring(1));
			sp++;
			String newCourseId="";
			if(sp >=1 && sp <= 9) {
				newCourseId="C00"+sp;
			}
			if(sp >=10 && sp <= 99) {
				newCourseId="C0"+sp;
			}
			if(sp >=100 && sp <= 999) {
				newCourseId="C"+sp;
			}
			return newCourseId;
		} catch (SQLException err) {
			logger.error(err.getMessage());
		}
		return null;
	}
	
	public String generateTrainingId(){
		 con=DaoConnection.getConnection();
		String cmd="select case when max(TrainingId) is null then 'T000' else max(TrainingId) end Tid from  ScheduleTraining";
		try {
			ps=con.prepareStatement(cmd);
		 rs=ps.executeQuery(); 
			rs.next();
			String trainingId=rs.getString("Tid");
			int sp=Integer.parseInt(trainingId.substring(1));
			sp++;
			String newTrainingId="";
			if(sp >=1 && sp <= 9) {
				newTrainingId="T00"+sp;
			}
			if(sp >=10 && sp <= 99) {
				newTrainingId="T0"+sp;
			}
			if(sp >=100 && sp <= 999) {
				newTrainingId="T"+sp;
			}
			return newTrainingId;
		} catch (SQLException err) {
			logger.error(err.getMessage());
		}
		return null;
	}
	
	public String generateRegisterId(){
		 con=DaoConnection.getConnection();
		String cmd="select case when max(RegisterId) is null then 'R000' else max(RegisterId) end Rid from  RegisterCourse";
		try {
			ps=con.prepareStatement(cmd);
			 rs=ps.executeQuery(); 
			rs.next();
			String registerId=rs.getString("Rid");
			int sp=Integer.parseInt(registerId.substring(1));
			sp++;
			String newRegisterId="";
			if(sp >=1 && sp <= 9) {
				newRegisterId="R00"+sp;
			}
			if(sp >=10 && sp <= 99) {
				newRegisterId="R0"+sp;
			}
			if(sp >=100 && sp <= 999) {
				newRegisterId="R"+sp;
			}
			return newRegisterId;
		} catch (SQLException err) {
			logger.error(err.getMessage());
		}
		return null;
	}
	
}
