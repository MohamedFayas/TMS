package com.trainingmanagement;
import static org.junit.Assert.assertEquals;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.junit.Test;
public class UsersTest {
	
	Users objUsers=new Users();
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	CallableStatement stmt;
	
	@Test
	public void testGetters(){
		
		objUsers.setTypeUser("ADMIN");
		assertEquals("ADMIN",objUsers.getTypeUser());
		
		objUsers.setPassword("amita");
		assertEquals("amita",objUsers.getPassword());
		
		objUsers.setEmpno(1);
		assertEquals(1,objUsers.getEmpno());
		
		objUsers.setName("ram");
		assertEquals("ram",objUsers.getName());
		
		objUsers.setJob("developer");
		assertEquals("developer",objUsers.getJob());
		
		objUsers.setSalary(90000);
		assertEquals(90000,objUsers.getSalary());
		
		objUsers.setMgrno(1);
		assertEquals(1,objUsers.getMgrno());
		
		objUsers.setContactNumber("985264756");
		assertEquals("985264756",objUsers.getContactNumber());
		
		objUsers.setMail("ramya@gmail.com");
		assertEquals("ramya@gmail.com",objUsers.getMail());

	}
	@Test
	public void testViewDetails(){
		objUsers=new Users().viewDetails(1);
		assertEquals(objUsers.getEmpno(), 1);
		assertEquals(objUsers.getName(), "Himanshu");
		assertEquals(objUsers.getJob(), "developer");
		assertEquals(objUsers.getSalary(),4000 );
		assertEquals(objUsers.getMgrno(), 3);
		assertEquals(objUsers.getContactNumber(),"9903977922");
		assertEquals(objUsers.getMail(), "aryan@gmail.com");
		
	}
	


}
