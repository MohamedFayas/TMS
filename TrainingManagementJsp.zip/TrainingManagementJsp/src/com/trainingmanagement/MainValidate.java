package com.trainingmanagement;

public class MainValidate {
	public static void main(String[] args) {
		Users obj =new Users();
		obj.viewDetails(1);
		System.out.println(obj.getName());
	}

}
