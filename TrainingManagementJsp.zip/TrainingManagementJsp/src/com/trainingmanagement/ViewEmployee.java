package com.trainingmanagement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class ViewEmployee {
	static Logger logger=Logger.getLogger(ViewEmployee.class);
	int username;
	String registerId;
	String employeename;
	String job;
	String approvalStatus;
	String coursename;
	String courseId;
	String trainingId;
	String venue;
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public String getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(String trainingId) {
		this.trainingId = trainingId;
	}
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getRegisterId() {
		return registerId;
	}
	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}
	public int getUsername() {
		return username;
	}
	public void setUsername(int username) {
		this.username = username;
	}
	public String getEmployeename() {
		return employeename;
	}
	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	PreparedStatement pst;
	Connection con;
	public List<ViewEmployee> viewEmployee(int mgrno){
		List<ViewEmployee> listUsers=new ArrayList();
		ViewEmployee objEmploy;
		String sql="select r.username as eno,r.registerid as regid,Employeename,job,ApprovalStatus,coursename from"
				+ " registerCourse r inner join ScheduleTraining tc on r.trainingid=tc.trainingid "
				+ " inner join users on r.username=users.empno inner join trainingCourses "
				+ "on tc.courseid=trainingcourses.courseId where mgrno=?";
		con=DaoConnection.getConnection();
		try {
			pst=con.prepareStatement(sql);
			pst.setInt(1, mgrno);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				objEmploy=new ViewEmployee();
				objEmploy.setUsername(rs.getInt("eno"));
				objEmploy.setRegisterId(rs.getString("regid"));
				objEmploy.setEmployeename(rs.getString("employeeName"));
				objEmploy.setCoursename(rs.getString("coursename"));
				objEmploy.setJob(rs.getString("job"));
				objEmploy.setApprovalStatus(rs.getString("ApprovalStatus"));
				listUsers.add(objEmploy);
				}
			return listUsers;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return listUsers;	
	}
	public List<ViewEmployee> viewNomination(String courseId){
		List<ViewEmployee> listUsers=new ArrayList();
		ViewEmployee objEmploy;
		String sql="select RegisterId as regid,r.userName as eno,EmployeeName,ApprovalStatus"
				+ " from RegisterCourse r inner join ScheduleTraining st on r.Trainingid=st.trainingid "
				+ "inner join Users on users.empno=r.username where courseid=? ";
		con=DaoConnection.getConnection();
		try {
			objEmploy=new ViewEmployee();
			pst=con.prepareStatement(sql);
			pst.setString(1,courseId);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				objEmploy.setUsername(rs.getInt("eno"));
				objEmploy.setRegisterId(rs.getString("regid"));
				objEmploy.setEmployeename(rs.getString("employeeName"));
				objEmploy.setApprovalStatus(rs.getString("ApprovalStatus"));
				listUsers.add(objEmploy);
				}
			return listUsers;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return listUsers;	
	}String str="CourseName";
	
	public List<ViewEmployee> viewTrainingSchedule(){
		
		List<ViewEmployee> listUsers=new ArrayList();
		ViewEmployee objEmploy;
		String sql="Select * from trainingCourses";
		con=DaoConnection.getConnection();
		try {
			pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				objEmploy=new ViewEmployee();
				objEmploy.setUsername(rs.getInt("empno"));
				
				objEmploy.setCoursename(rs.getString(str));
				objEmploy.setCourseId(rs.getString("CourseId"));
				listUsers.add(objEmploy);
			}
			return listUsers;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return listUsers;	
	}
public List<ViewEmployee> viewCompletedCourses(int eno){
		
		List<ViewEmployee> listUsers=new ArrayList();
		ViewEmployee objEmploy;
		String sql="select r.trainingId as tid,tc.courseId as cid,coursename,venue from registerCourse r inner join"
				+ " ScheduleTraining s on s.trainingid=r.trainingId inner join trainingCourses tc on "
				+ "s.courseid=tc.courseid where username=?";
		con=DaoConnection.getConnection();
		try {
			pst=con.prepareStatement(sql);
			pst.setInt(1, eno);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				objEmploy=new ViewEmployee();
				objEmploy.setTrainingId(rs.getString("tid"));
				objEmploy.setCoursename(rs.getString(str));
				objEmploy.setCourseId(rs.getString("cid"));
				objEmploy.setVenue(rs.getString("venue"));
				listUsers.add(objEmploy);
			}
			return listUsers;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return listUsers;	
	}
public List<ViewEmployee> viewTaughtCourses(int eno){
	
	List<ViewEmployee> listUsers=new ArrayList();
	ViewEmployee objEmploy;
	String sql="Select tc.courseId as cid,trainingid,coursename,venue"
			+ " from trainingcourses tc inner join scheduletraining st on tc.courseid=st.courseid where empno=?";
	con=DaoConnection.getConnection();
	try {
		pst=con.prepareStatement(sql);
		pst.setInt(1, eno);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
			objEmploy=new ViewEmployee();
			objEmploy.setTrainingId(rs.getString("trainingid"));
			objEmploy.setCoursename(rs.getString(str));
			objEmploy.setCourseId(rs.getString("cid"));
			objEmploy.setVenue(rs.getString("venue"));
			listUsers.add(objEmploy);
		}
		return listUsers;
	} catch (SQLException e) {
		logger.error(e.getMessage());
	}
	return listUsers;	
}
	
}
