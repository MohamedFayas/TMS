package com.trainingmanagement;

import java.io.BufferedReader;
import java.io.FileReader;

import org.apache.log4j.Logger;
class GetUserPass{
	static Logger logger=Logger.getLogger(GetUserPass.class);
	private String username;
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public GetUserPass userPass() {
		GetUserPass obj=new GetUserPass();
        FileReader fr;
		try {
			fr = new FileReader("D:\\JAVA\\NewJava\\TrainingManagementJSP\\password.txt");
	        BufferedReader reader=new BufferedReader(fr);
	        String line=reader.readLine();
	        	obj.setUsername(line);
	        	line=reader.readLine();
	        	obj.setPassword(line);
	        	reader.close();
	        	return obj;
		} catch (Exception err) {
			logger.error(err.getMessage());
		}
		return null;
	}
}
