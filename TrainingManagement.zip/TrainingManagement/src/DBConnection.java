    
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;


public class DBConnection 
{
	private DBConnection()
	{}
	static Logger logger = Logger.getLogger(DBConnection.class);
	public static  Connection getConnection()
	{
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			return DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:ORCL",
					"fayas","fayas");
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e);
		} 
		return null;
	}
}